package com.example.remotemonitoringapp;

public class commentData {
    String comment;
    String datetime;
    String commentBy;

    commentData(String comment, String datetime, String commentBy)
    {
        this.comment = comment;
        this.datetime = datetime;
        this.commentBy = commentBy;

    }
}